import React from 'react';

const MentorshipRequests = () => {
  return (
    <div>
      <h1>Mentorship Requests</h1>
      {/* Add request components here */}
    </div>
  );
};

export default MentorshipRequests;