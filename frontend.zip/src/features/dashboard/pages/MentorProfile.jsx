import React from 'react';

const MentorProfile = () => {
  return (
    <div>
      <h1>Mentor Profile</h1>
      {/* Add profile components here */}
    </div>
  );
};

export default MentorProfile;