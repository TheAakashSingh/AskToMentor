import React from 'react';

const AdditionalContent = () => {
  return (
    <div className="additional-content">
      <h3>Coming Soon ........</h3>
     
    </div>
  );
};

export default AdditionalContent;
