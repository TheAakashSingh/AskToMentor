import React, { useState } from "react";
import { Button, Input, Typography, Space, Form } from "antd";
import { MdEmail } from "react-icons/md";
import { BiSolidUser } from "react-icons/bi";
import 'antd/dist/reset.css'; // Import Ant Design CSS
import '../../../styles/signupMentor.css'; // Import your custom CSS

const { Title } = Typography;

const SignupMentor = () => {
  const [method, setMethod] = useState(null);
  const [form] = Form.useForm();

  const handleSubmit = (values) => {
    console.log(values);
    // Implement your submission logic here
  };

  return (
    <div className='signup-mentor-container'>
      <div className="signup-mentor-box">
        <Title level={2} className="signup-mentor-title">Sign Up as a Mentor</Title>
        
        {!method ? (
          <Space direction="vertical" size="large" className="signup-mentor-buttons">
            <Button
              type="primary"
              size="large"
              onClick={() => setMethod('google')}
              className="signup-mentor-button-google"
            >
              Sign Up with Google
            </Button>
            <Button
              type="default"
              size="large"
              onClick={() => setMethod('linkedin')}
              className="signup-mentor-button-linkedin"
            >
              Sign Up with LinkedIn
            </Button>
          </Space>
        ) : (
          <Form
            form={form}
            layout="vertical"
            className="signup-mentor-form"
            onFinish={handleSubmit}
          >
            <Form.Item
              label="Name"
              name="name"
              rules={[{ required: true, message: 'Please input your name!' }]}
            >
              <Input
                placeholder="Enter your name"
                prefix={<BiSolidUser />}
              />
            </Form.Item>

            <Form.Item
              label="Mobile Number"
              name="mobile"
              rules={[{ required: true, message: 'Please input your mobile number!' }]}
            >
              <Input
                placeholder="Enter your mobile number"
                type="number"
                prefix={<MdEmail />}
              />
               <marquee className='marquess1' behavior="smooth" direction="">
               Please note that this number is required for us to verify your account. A representative will call or text you regarding our platform.
               </marquee>
            </Form.Item>

            {method === 'google' ? (
              <>
                <Form.Item
                  label="Gmail Address"
                  name="email"
                  rules={[{ required: true, message: 'Please input your Gmail address!' }]}
                >
                  <Input
                    placeholder="Enter your Gmail address"
                    type="email"
                    prefix={<MdEmail />}
                  />
                </Form.Item>
              </>
            ) : (
              <>
                <Form.Item
                  label="LinkedIn Profile URL"
                  name="linkedinUrl"
                  rules={[{ required: true, message: 'Please input your LinkedIn profile URL!' }]}
                >
                  <Input
                    placeholder="Enter your LinkedIn profile URL"
                    type="link"
                    prefix={<BiSolidUser />}
                  />
                </Form.Item>
              </>
            )}

            <Form.Item>
              <Button type="primary" htmlType="submit" className="signup-mentor-submit-button">
                Submit
              </Button>
              
            </Form.Item>
          </Form>
        )}
      </div>
    </div>
  );
};

export default SignupMentor;
